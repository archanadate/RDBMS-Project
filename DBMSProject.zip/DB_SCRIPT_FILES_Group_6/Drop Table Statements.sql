-----------------------------drop table statements------------------------------

drop table PAYMENT;

drop table FinalORDER;

drop table ProductORDER;

drop table Review;

drop table Cart;

drop table Product;

drop table Shopper;

--------------------------drop sequences statements-----------------------------

drop sequence userid_seq;

drop sequence finalorderid_seq;

drop sequence cartid_seq;

drop sequence reviewid_seq;

drop sequence payment_seq;